package Package_TestScript;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.util.concurrent.TimeUnit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class WeBuy {
	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();
	String basketNum, prod_name_list;
	int basket_num;
	String read_from_excel[][] = new String[2][6];
	
	@Before
	public void setUp() throws Exception 
	{
		driver = new FirefoxDriver();
		baseUrl = "https://uk.webuy.com/";
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test
	public void test() throws InterruptedException, IOException {
		String[] valueToWrite = new String[2];
		String check, basketTotal;
		Float basket_total;
		int prod_in_bas_cnt = 0;
		driver.manage().window().maximize();
		driver.get(baseUrl);        
		Thread.sleep(10000);
		WebElement actArea = driver.findElement(By.cssSelector(".deliver-overlay"));
		Actions builder= new Actions(driver);
		builder.build();
		Thread.sleep(1000);
		builder.moveToElement(actArea, 970, 62).click().perform();
		Thread.sleep(1000);
		
		for (int i = 6; i <= 11; i++) {
			check = driver.findElement(By.cssSelector("body > div.mainPageArea > div.centreColArea.customcontrols > div:nth-child(" + i +") > div.btnSection > a:nth-child(2) > div > span")).getText();
			if (check.contains("Buy now") || check.contains("I want to buy this item")) {
				prod_name_list = driver.findElement(By.cssSelector("body > div.mainPageArea > div.centreColArea.customcontrols > div:nth-child(" + i +") > div.hotProductDetails > div.prodDetails > div.prodName > a")).getText();
				Thread.sleep(3000);
				valueToWrite[0] = prod_name_list;
				valueToWrite[1] = "1";
				writeExcel(System.getProperty("user.dir")+"","weBuyProdList.xls","Sheet1",valueToWrite);
				driver.findElement(By.cssSelector("body > div.mainPageArea > div.centreColArea.customcontrols > div:nth-child(" + i +") > div.btnSection > a:nth-child(2) > div > span")).click();
			    prod_in_bas_cnt++;
			    basketNum = driver.findElement(By.cssSelector("#buyBasketCount")).getText();
			    basket_num = Integer.parseInt(basketNum);
			    if (basket_num == prod_in_bas_cnt) {
				System.out.println("Basket Number = " + basket_num + ". That's Correct!");
			    } else {
				    System.out.println("Basket Number = " + basket_num + ". That's Incorrect!");
			    }
			}
			if (prod_in_bas_cnt == 5) {
				break;
			}
		}
		if (prod_in_bas_cnt != 5) {
			for (int i = 4;; i++) {
				check = driver.findElement(By.cssSelector("#content > div:nth-child(" + i +") > div.btnSection > a:nth-child(2) > div > span")).getText();
				if (check.contains("Buy now") || check.contains("I want to buy this item")) {
					prod_name_list = driver.findElement(By.cssSelector("#content > div:nth-child(" + i +") > div.hotProductDetails > div.prodDetails > div.prodName > a")).getText();
					Thread.sleep(3000);
					valueToWrite[0] = prod_name_list;
					valueToWrite[1] = "1";
					writeExcel(System.getProperty("user.dir")+"","weBuyProdList.xls","Sheet1",valueToWrite);
					driver.findElement(By.cssSelector("#content > div:nth-child(" + i +") > div.btnSection > a:nth-child(2) > div > span")).click();
				    prod_in_bas_cnt++;
				    basketNum = driver.findElement(By.cssSelector("#buyBasketCount")).getText();
				    basket_num = Integer.parseInt(basketNum);
				    if (basket_num == prod_in_bas_cnt) {
					System.out.println("Basket Number = " + basket_num + ". That's Correct!");
				    } else {
					    System.out.println("Basket Number = " + basket_num + ". That's Incorrect!");
				    }
				}
				if (prod_in_bas_cnt == 5) {
					break;
				}
			}
		}
		try 
		{
		     
		    //FileInputStream file = new FileInputStream(new File("C:\\test.xls"));
		    InputStream file = new FileInputStream("D:\\AlqamaAnsari\\src\\weBuyProdList.xls");
		    //Get the workbook instance for XLS file 
		    HSSFWorkbook workbook = new HSSFWorkbook(file);
		 
		    //Get first sheet from the workbook
		    HSSFSheet sheet = workbook.getSheetAt(0);
		     
		    //Iterate through each rows from first sheet
		    java.util.Iterator<Row> rowIterator = sheet.iterator();
		    int i = 0, j = 0;
		    
		    while(rowIterator.hasNext()) 
		    {	i = 0; 	        
		    	Row row = rowIterator.next();
		         
		        //For each row, iterate through each columns
		        java.util.Iterator<Cell> cellIterator = row.cellIterator();
		        while(cellIterator.hasNext()) 
		        {
		        	Cell cell = cellIterator.next();
		             
		            switch(cell.getCellType()) 
		            {
		                case Cell.CELL_TYPE_BOOLEAN:
		                    //System.out.println(cell.getBooleanCellValue() + "\t\t");
		                    break;
		                case Cell.CELL_TYPE_NUMERIC:
		                    //System.out.println(cell.getNumericCellValue() + "\t\t");
		                    break;
		                case Cell.CELL_TYPE_STRING:
		                    //System.out.println(cell.getStringCellValue() + "\t\t");
		                    read_from_excel[i][j] = cell.getStringCellValue();
		                    break;
		            }
		            i++;
		        }
		        j++;
		    }
		    file.close();
		     
		} catch (FileNotFoundException e) 
			{
				e.printStackTrace();
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		driver.findElement(By.cssSelector("body > div.mainPageArea > div.rightColArea > div.buyBasketArea > div.buyBasketContent > table > tbody > tr > td.basketTableCellLnk > a:nth-child(1)")).click();
		Thread.sleep(5000);
		if (isElementPresent(By.cssSelector(".deliver-overlay"))) {
		    WebElement actArea1 = driver.findElement(By.cssSelector(".deliver-overlay"));
		    builder.moveToElement(actArea1, 970, 62).click().perform();
		}
		String[] prod_name = new String[5];
		String[] prod_cost = new String[5];
		String[] prod_quantity = new String[5];
		float[] prodCost = new float[5];
		double sum = 2.50;
		for (int i = 1; i < 6; i++) {
			prod_name[i-1] = driver.findElement(By.cssSelector("body > div.mainPageArea > div.centreColArea > div.basketPageArea.marginTop > div:nth-child(2) > form > table > tbody > tr:nth-child(" + i + ") > td:nth-child(2)")).getText();
			prod_quantity[i-1] = driver.findElement(By.cssSelector("body > div.mainPageArea > div.centreColArea > div.basketPageArea.marginTop > div:nth-child(2) > form > table > tbody > tr:nth-child(" + i + ") > td:nth-child(1) > div > select > option")).getText();
			if (prod_name[i-1].contains(read_from_excel[0][1]) || prod_name[i-1].contains(read_from_excel[0][2]) || prod_name[i-1].contains(read_from_excel[0][3]) || prod_name[i-1].contains(read_from_excel[0][4]) || prod_name[i-1].contains(read_from_excel[0][5])) {
				System.out.println(prod_name[i-1] + " - That's the product I ordered.");
			} else {
				System.out.println(prod_name[i-1] + " - That's not the product I ordered.");
			}
			if (prod_quantity[i-1].contains(read_from_excel[1][i])) {
				System.out.println("Quantity = " + prod_quantity[i-1] + " - That's the correct quantity of " + prod_name[i-1] + ".");
			} else {
				System.out.println("Quantity = " + prod_quantity[i-1] + " - That's not the correct quantity of " + prod_name[i-1] + ".");
			}
			prod_cost[i-1] = driver.findElement(By.cssSelector("body > div.mainPageArea > div.centreColArea > div.basketPageArea.marginTop > div:nth-child(2) > form > table > tbody > tr:nth-child(" + i + ") > td:nth-child(4)")).getText();
			System.out.println(prod_cost[i-1]);
			prod_cost[i-1] = prod_cost[i-1].substring(1);
			prodCost[i-1] = Float.parseFloat(prod_cost[i-1]);
			sum += prodCost[i-1];
			Thread.sleep(2000);
		}
		System.out.println("total = " +sum);
		basketTotal = driver.findElement(By.cssSelector("body > div.mainPageArea > div.centreColArea > div.basketPageArea.marginTop > div:nth-child(2) > form > table > tbody > tr:nth-child(8) > td:nth-child(2) > strong")).getText();
		basketTotal = basketTotal.substring(1);
		basket_total = Float.parseFloat(basketTotal);
		if (sum == basket_total) {
			System.out.println("Basket Total = " + basket_total + ". That's Correct!");
		} else {
			System.out.println("Basket Total = " + basket_total + ". That's Incorrect!");
		}
	}
	public void writeExcel(String filePath,String fileName,String sheetName,String[] dataToWrite) throws IOException{
		   
	    //Create a object of File class to open xls file
	 
	    File file = new File(filePath+"\\"+fileName);
	 
        //Create an object of FileInputStream class to read excel file
	 
	    FileInputStream inputStream = new FileInputStream(file);
	 
	    Workbook weBuy = null;
	 
	    //Find the file extension by splitting file name in substring and getting only extension name
	 
	    String fileExtensionName = fileName.substring(fileName.indexOf("."));
	 
	    //Check condition if the file is xls file
	 
	    if(fileExtensionName.equals(".xls")){
	        weBuy = new HSSFWorkbook(inputStream);
	    }
	    //Read excel sheet by sheet name    
	 
	    Sheet sheet = weBuy.getSheet(sheetName);
	 
	    //Get the current count of rows in excel file
	 
	    int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
	 
	    //Get the first row from the sheet
	 
	    Row row = sheet.getRow(0);
	 
	    //Create a new row and append it at last of sheet
	 
	    Row newRow = sheet.createRow(rowCount+1);
	 
	    //Create a loop over the cell of newly created Row
	 
	    for(int j = 0; j < row.getLastCellNum(); j++){
	 
	        //Fill data in row
	 
	        Cell cell = newRow.createCell(j);
	 
	        cell.setCellValue(dataToWrite[j]);
	 
	    }
	 
	    //Close input stream
	 
	    inputStream.close();
	 
	    //Create an object of FileOutputStream class to create write data in excel file
	 
	    FileOutputStream outputStream = new FileOutputStream(file);
	 
	    //write data in the excel file
	 
	    weBuy.write(outputStream);
	 
	    //close output stream
	 
	    outputStream.close();
	 
	}
	@After
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}
}
