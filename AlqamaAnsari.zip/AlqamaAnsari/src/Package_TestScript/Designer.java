package Package_TestScript;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Designer {
	public WebDriver driver;
	public String baseUrl;
	public StringBuffer verificationErrors = new StringBuffer();
	String basketNum, prod_name_list;
	int basket_num;
	String read_from_excel[][] = new String[2][6];
	
	@Before
	public void setUp() throws Exception 
	{
		driver = new FirefoxDriver();
		baseUrl = "https://www.designerexchange.com/";
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test
	public void test() throws InterruptedException, IOException {
		driver.get(baseUrl);
		driver.findElement(By.xpath("//*[@id='menu']/li[7]/a")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='Quote_uName']")).sendKeys("Alqama Ansari");
		driver.findElement(By.xpath("//*[@id='Quote_email']")).sendKeys("alqamaansari@gmail.com");
		Select selectDesigner = new Select(driver.findElement(By.xpath("//*[@id='Quote_item_id']")));
		selectDesigner.selectByVisibleText("Alexander McQueen");
		driver.findElement(By.xpath("//*[@id='Quote_item_name']")).sendKeys("Any Item");
		driver.findElement(By.xpath("//*[@id='Quote_item_desc']")).sendKeys("Description text");
		
		
		driver.findElement(By.id("uploadmorelnk")).click();
 		 for(String winHandle : driver.getWindowHandles())								//Switch to new window opened
  			{
  		    	driver.switchTo().window(winHandle);
  			}
	        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	        Thread.sleep(2000);
	    
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		 JavascriptExecutor js = (JavascriptExecutor)driver;
		 js.executeScript("$(\"input[type=file]\").css({'visibility':'visible','height':'10px','width':'10px'})");
		 
		 driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		WebElement el=driver.findElement(By.cssSelector("input[type=file]"));
		el.sendKeys("D:\\selenium Jar\\apple_logo.png");
		
 		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='dzuploadbttn']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='myModalupload']/div[1]/button")).click();
		Thread.sleep(2000);
 		driver.findElement(By.xpath("//*[@id='quotefrm']/div[3]/input")).click();
 		
		Thread.sleep(2000);
			String msg=driver.findElement(By.xpath("//*[@id='Quote_msg11']")).getText();
		if(msg.startsWith("Thank you"))
			{
			System.out.println(" >> Successfully Automated Submit Quote Request");
			}
		else
		{
			System.out.println("Error in submit quote");
		}
		
		//driver.quit();
	
	}

}
